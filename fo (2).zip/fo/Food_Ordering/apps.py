from django.apps import AppConfig


class FoodOrderingConfig(AppConfig):
    name = 'Food_Ordering'
